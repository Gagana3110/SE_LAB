| Issue | Type | Line(s) | Description | Fix Approach |
| ----- | ---- | ------- | ----------- | ------------ |
| os.system with string concat | Security (Bandit B605/B607, High) | lockScreen | Command injection risk | subprocess.run with argument list, no shell |
| MD5 hashing | Security (Bandit B324, High) | hashAnswer | Weak hash algorithm | Use SHA-256 |
| Hardcoded password | Security (Bandit B105, Low) | PROCTOR_PASSWORD | Secret in source | Read from environment variable |
| random.choice | Security (Bandit B311, Low) | pickBonusQuestion | Non-crypto PRNG flagged | Use secrets.choice |
| Mutable default argument | Bug (Pylint W0102) | gradeStudent | penalties={} shared across calls | Default None, create dict inside function |
| camelCase names | Convention (Pylint C0103) | all functions/args | Not snake_case | Rename to snake_case, constant RESULTS |
| Missing docstrings | Convention (Pylint C0114/C0116) | module, functions | No documentation | Add docstrings |
| range(len()) loop | Refactor (Pylint C0200) | gradeStudent | Unpythonic iteration | Use enumerate |
| else after return | Refactor (Pylint R1705) | getGrade | Unnecessary elif/else | Early returns |
| Spacing/blank lines/long line | Style (Flake8 E225, E261, E128, E501) | main | PEP 8 violations | Reformat |
