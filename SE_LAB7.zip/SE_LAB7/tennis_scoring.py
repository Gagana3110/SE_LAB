import re

# ASCII digits only: int() would also accept "+5", " 5 ", "1_0" and
# non-ASCII digits such as Arabic-Indic numerals, which we treat as invalid.
_NUMBER = re.compile(r"[0-9]+")

_POINTS = {'0': 0, '15': 1, '30': 2, '40': 3}


def _to_count(token):
    """Convert a non-negative integer string to int, or return None."""
    token = token.strip()
    if _NUMBER.fullmatch(token) is None:
        return None
    try:
        return int(token)
    except ValueError:  # e.g. absurdly long digit strings (int-size limit)
        return None


def parse_score(text):
    """Parse 'A-B' into (A, B). Returns None for any invalid input."""
    if not isinstance(text, str):
        return None
    parts = text.split('-')
    if len(parts) != 2:
        return None
    a, b = _to_count(parts[0]), _to_count(parts[1])
    if a is None or b is None:
        return None
    return a, b


def game_lead(text):
    """Return points(first) - points(second) for a game score such as '40-30'.
    Returns None for any invalid input."""
    if not isinstance(text, str):
        return None
    parts = text.split('-')
    if len(parts) != 2:
        return None
    first, second = parts[0].strip(), parts[1].strip()
    if first not in _POINTS or second not in _POINTS:
        return None
    return _POINTS[first] - _POINTS[second]


def set_spread(games_csv):
    """Return max - min of a comma-separated list of games won.
    Returns None for empty, malformed or non-string input."""
    if not isinstance(games_csv, str):
        return None
    games = []
    for token in games_csv.split(','):
        n = _to_count(token)
        if n is None:
            return None
        games.append(n)
    return max(games) - min(games)


def main():
    print("==== Running parse_score ====")
    user_input = input("Enter points won as A-B (e.g. 3-2): ")
    result = parse_score(user_input)
    print("Points A and B:", result if result is not None else "Invalid input")

    print("\n==== Running game_lead ====")
    user_input = input("Enter a game score (e.g. 40-30): ")
    result = game_lead(user_input)
    print("Lead in Points:", result if result is not None else "Invalid input")

    print("\n==== Running set_spread ====")
    user_input = input("Enter games won per set as CSV (e.g. 6,4,7): ")
    result = set_spread(user_input)
    print("Spread:", result if result is not None else "Invalid input")


if __name__ == "__main__":
    main()
