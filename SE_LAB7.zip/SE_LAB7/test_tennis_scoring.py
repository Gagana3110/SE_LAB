from hypothesis import given, strategies as st
from tennis_scoring import parse_score, game_lead, set_spread

# Any text, None, or other non-string junk
anything = st.text() | st.none() | st.integers() | st.floats() | st.binary()


# ---------- 1. Robustness: the functions must never crash ----------
@given(anything)
def test_parse_score_no_crash(s):
    try:
        parse_score(s)
    except Exception as e:
        assert False, f"parse_score crashed with: {e!r} on input {s!r}"


@given(anything)
def test_game_lead_no_crash(s):
    try:
        game_lead(s)
    except Exception as e:
        assert False, f"game_lead crashed with: {e!r} on input {s!r}"


@given(anything)
def test_set_spread_no_crash(s):
    try:
        set_spread(s)
    except Exception as e:
        assert False, f"set_spread crashed with: {e!r} on input {s!r}"


# ---------- 2. Correctness: valid inputs give the right answer ----------
@given(st.integers(0, 10**6), st.integers(0, 10**6))
def test_parse_score_roundtrip(a, b):
    assert parse_score(f"{a}-{b}") == (a, b)


@given(st.sampled_from(["0", "15", "30", "40"]),
       st.sampled_from(["0", "15", "30", "40"]))
def test_game_lead_valid(x, y):
    order = ["0", "15", "30", "40"]
    assert game_lead(f"{x}-{y}") == order.index(x) - order.index(y)


@given(st.lists(st.integers(0, 100), min_size=1))
def test_set_spread_valid(games):
    result = set_spread(",".join(map(str, games)))
    assert result == max(games) - min(games)
    assert result >= 0


# ---------- 3. Invalid inputs are rejected (None), not mis-parsed ----------
@given(st.text().filter(lambda t: t.count("-") != 1))
def test_parse_score_wrong_separator_count(s):
    assert parse_score(s) is None


@given(st.text().filter(lambda t: t.count("-") != 1))
def test_game_lead_wrong_separator_count(s):
    assert game_lead(s) is None


@given(st.integers(max_value=-1))
def test_negative_games_rejected(n):
    assert set_spread(f"{n},3") is None


def test_known_edge_cases():
    for bad in ["", "-", "3-", "-3", "3--2", "a-b", "3-2-1", "3 - x", None, 5, "٣-٢", "+3-2"]:
        assert parse_score(bad) is None, bad
    for bad in ["", "40", "50-0", "40-", "love-15", None, "40-30-0"]:
        assert game_lead(bad) is None, bad
    for bad in ["", ",", "1,,3", "one,two", "6,", ",6", None, "1.5,2", "-1,2"]:
        assert set_spread(bad) is None, bad
